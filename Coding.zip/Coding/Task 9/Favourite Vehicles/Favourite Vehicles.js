//Task 9.2 Vehicles

let vehicles = ["Lamboghini Sesto Elemento", "Ferrari Testarossa", "1967 Shelby GT500", "1967 Chevy Corvette Stingray", "Mercedes-Benz AMG GT S"]

let favourite = "1967 Shelby GT500"

for(let x = 0; x < vehicles.length; x++){
    if(favourite === vehicles[x]){
        console.log(vehicles[x] + " Is my favourite vehicle")
    }else{
        console.log(vehicles[x] + " Is not my favourite vehicle")
    }

}
//
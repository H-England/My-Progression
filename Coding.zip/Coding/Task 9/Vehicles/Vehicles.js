//Task 9.2 Vehicles

let vehicles = ["Lamboghini Sesto Elemento", "Ferrari Testarossa", "1967 Shelby GT500", "1967 Chevy Corvette Stingray", "Mercedes-Benz AMG GT S "]

for(let x = 0; x < vehicles.length; x++){
    console.log("I would love to drive  a " + vehicles[x])

}
//
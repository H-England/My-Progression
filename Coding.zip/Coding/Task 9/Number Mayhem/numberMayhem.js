//Task 9.1 numberMayhem

console.log("The Countdown from 20")
for(let i = 20; i >= 0; i--){
    console.log(i)
}

console.log("")
console.log("The Countdown from 20 with only even numbers")
for(let e = 20; e >= 0; e-=2){
    console.log(e)
}

console.log("")

let p = "*"

//Trial and Error Section

//for( let x = 0; x < 5; x ++){
 //   for(p = "*"; p.length < 5; p += p){
 //       console.log(p)
 //   }    
//}

for( let x = 0; x < 1; x ++){
    for(p = "*"; p.length <= 5; p += "*"){
        console.log(p)
        
    }    
}

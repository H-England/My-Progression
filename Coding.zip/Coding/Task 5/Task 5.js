//Task 5 Are you an Adult?

let age = Number(prompt("How old are you ? "))

let num = age % 7 === 0

console.log(num)

switch(age % 7){
    case 0:
        switch(age % 11){
            case 0:
                console.log("Divis 7 and 11")
                break
            default:
                console.log("Only 7")
                break
        }
        break;
    default:
        switch(age % 11){
            case 0:
                console.log("Just 11")
                break
            default:
                console.log("neither")
                break

        }
}
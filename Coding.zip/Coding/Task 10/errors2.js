// This example program is meant to demonstrate errors.
 
// There are some errors in this program, try run the program by pressing F5.
// Now look at the error messages and find and fix the errors.

//Adding speech marks to its a string(Runtime)
let animal = "Lion"
//removed random indentation(Syntax)
let animalType = "cub";
let numberOfTeeth = 16;
//making numberOfLegs an integer(Syntax)
let numberOfLegs = 4;
//Turning this into a template literal as it looks like its trying to be.(Syntax)
//Adding ther $ to each start of the curly brackets.(Syntax)
//Swapping the number_of_teeth and animal_type as they are in the wrong order (Logical)
//finally removing the underscore and adding the capitals.(Runtime)
fullSpec = (`This is a ${animal}. It is a ${animalType} and it has ${numberOfTeeth} teeth`)

//changing the if statement so it actually prints the code(Syntax)
if (numberOfLegs = 4) {
        //added brackets to console.log and removed the underscore and added a capital to the s (Syntax and Runtime)
console.log (fullSpec);
}

// This example program is meant to demonstrate errors.
 
// There are some errors in this program.
// Now look at the error messages and find and fix the errors.

//Removed random indentations
// Added Brackets for the console.logs throughout the program(Syntax)
console.log ("Welcome to the error program");
//removed capital letter from console.log below(Runtime)
console.log ("\n");

//removed the extra equals symbol(Runtime)
//removed ageStr as it is completely useless and does nothing(Logical)
let age = 24; 

    // Added spaces in the strings to look more neat(Logical)
console.log("I'm "+ age +" years old.");
   
//removed speech marks so its an integer(Logical)

let three = 3;

let answerYears = (age + three);

    //removed the speech marks around the answerYears below(Logical)
console.log ("The total number of years: " + answerYears);
// Adding a missing let and also adding brackets (to look cleaner) and adding the missing Years on to answer(Logical and Syntax)
let answerMonths = (answerYears * 12)
// added a 6 to the answerMonths as in the string it says 6 months extra but no where in the code does it add those 6 months.(Logical)
console.log ("In 3 years and 6 months, I'll be " + (answerMonths + 6)  + " months old");

//HINT, 330 months is the correct answer
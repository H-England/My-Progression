//Task 10 - Creating Errors

name = "Harry England"
let age = "22"
let threeYearsTime = (age + 3)

Console.log("My name is " + (name) + "and I am " (age) "years old and in 3 years time I will be" + (threeYearsTime))
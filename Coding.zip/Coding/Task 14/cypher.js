//Task 14 - Capstone

let input = prompt("Please Enter A Word: ")


function conversion(string){
    let arr = []
    let cypher = string
    let ascii = 0 
    let value = 0 
    let a2s = 0
    let string2 = 0
    let value2 = a2s
    let newString =[]  
    
    //This loop is to turn the string into a ascii code
    for(let i = 0; i < string.length; i++ ){
        ascii = cypher.charCodeAt(i)
        arr.push(ascii)

        
    }
//This for loop is to convert the ascii to the encoded ascii value
    for(let j = 0; j < arr.length; j++){
        if((arr[j] + 15) >= 91 && arr[j] > 64 && arr[j] < 96){
            value = (arr[j] + 15) - 90
            arr[j] = (64 + value)
        } else if((arr[j] + 15) <= 90 && arr[j] > 64 ){
            arr[j] = arr[j] + 15
        }
        if((arr[j] + 15) >= 123 && arr[j] > 96 ){
            value = (arr[j] + 15) - 122
            arr[j] = (96 + value)
            
        }else if((arr[j] + 15) <= 122 && arr[j] > 96){
            arr[j] = arr[j] + 15
        }
        console.log(arr)
    }
    //This loop is to turn the ascii values back into a string
    for(let k = 0; k < arr.length; k++){
        a2s = arr[k]
        string2 = String.fromCharCode(a2s)
        newString.push(string2)
    }
    
    //Finally this is where I joined the array with the new string to make one full string
    let result = newString.join("")

    return result
}

// newString = conversion(string)

console.log(conversion(input))

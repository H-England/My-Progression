// An Email Simulation
/*
create your email class here
*/
class EmailConstructor{
    constructor(emailContents, fromAddress){
        this.hasBeenRead = false
        this.emailContents = emailContents
        this.isSpam = false
        this.fromAddress = fromAddress

		

    this.markAsRead = () => {
        

        this.hasBeenRead = true
        

    }
    this.markAsSpam = () =>{
    
        this.isSpam = true
        
    }
    }


}
//add email function with a while loop to add as many emails are you like
function addEmail(){
	
	cont = "y"
	while(cont.toLowerCase() === "y"){

	contents = prompt("Please Enter the Contents of the Email")
	address = prompt("Please Enter the address of the email")
	email2 = new EmailConstructor(contents, address)

	cont = prompt("Would you like to add more ? (y/n)")

	inbox.push(email2)
	}
}

function getCount(){
	count = inbox.length
	return count
}

function getEmail(index){
	console.log(inbox[index].emailContents)
	this.hasBeenRead = true
}
//getUnreadEmails function using a for loop to loop through they array to check which emails are unread and ouputting each array individually
function getUnreadEmails(){
	console.log(`Here is a list of the emails that are haven't been read:`)
	for(i = 0; i < inbox.length; i++){
		if(inbox[i].hasBeenRead == false){
			console.log(inbox[i])
		}else{

		}
	}
}
//getUnreadEmails function using a for loop to loop through they array to check which emails are marked as spam and ouputting each array individually
function getSpamEmails(){
	console.log(`Here is a list of the emails marked as Spam:`)
	for(i = 0; i < inbox.length; i++){
		if(inbox[i].isSpam === true){
			
			console.log(inbox[i])
		}
	}
	
}

let value = 0
let inbox = []



let a = new EmailConstructor("Contents", "Example@google.com")
let b = new EmailConstructor("Contents 2", "scammer@scam.net")
let c = new EmailConstructor("Please Delete me", "bin@binmail.com")
let d = new EmailConstructor("Read ME", "readme@glasses.com")

inbox.push(a, b, c, d)

userChoice = "";
while(userChoice != "7"){
	userChoice = prompt("What would you like to do:\n1. Read email\n2. Mark spam\n3. Send email\n4. Delete email\n5. View spam emails\n6. View unread emails\n7. quit?");
	if(userChoice == "1"){
		value = Number(prompt(`Which email would you like to read? 0 to ${inbox.length - 1}`))
		while(value > inbox.length - 1){
			value = Number(prompt(`Please choose a number between 0 and ${inbox.length - 1}`))
		}
		inbox[value].markAsRead()

	}else if(userChoice == "2"){
		
		value = Number(prompt(`Which email would you like to mark as spam? 0 to ${inbox.length - 1}`))
		while(value > inbox.length - 1){
			value = Number(prompt(`Please choose a number between 0 and ${inbox.length - 1}`))
		}
		inbox[value].markAsSpam()
		console.log(inbox[value])

	}else if(userChoice == "3"){
		
		addEmail(EmailConstructor)
		console.log("Your email has been added")
		console.table(inbox)

	}else if(userChoice == "4"){
		//Outputs objects to a table to show which emails are left and make it clear to choose which ones to delete
		console.table(inbox)
		value = Number(prompt(`Which email would you like to delete? 0 to ${inbox.length - 1}`))
		while(value > inbox.length - 1){
			value = Number(prompt(`Please choose a number between 0 and ${inbox.length - 1}`))
		}
		inbox.splice(value, 1)
		console.table(inbox)


	}else if(userChoice == "5"){
		
		getSpamEmails(inbox)

	}else if(userChoice == "6"){
		
		getUnreadEmails(inbox)

	}else if(userChoice == "7"){
		console.log("Goodbye");
	}else{
		console.log("Oops - incorrect input");
		
	}
}


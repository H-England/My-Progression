//Task 11 - Guest List

let list = []
let answer
let answer2 = "n"
let replace
let replace2 = "n"
let name2



do {
    if(list.length >= 10){ 
        console.log("You have entered the maximum of 10 Names")
        answer = "n"
    } else{
        let name = prompt("Please Enter a maximum 10 Names")
        list.push(name)
        answer = prompt("Would you like to add another name? (y/n)")
}
    
}while(answer.toLowerCase() == "y")

answer2 = prompt("Thank you, would you like to replace any of the name? (y/n)")

if(answer2.toLowerCase() !== "y"){
    console.log("Thank you. Your list is complete. " + list)
}else if(answer2.toLowerCase() == "y"){
    do{
        console.log(list)
        name2 = prompt("Please Enter then name you would like to replace")
        if(list.includes(name2)){
            list.splice(list.indexOf(name2),1)
            replace = prompt(`Enter the name you would to replace ${name2} with.`)
            list.push(replace)
        }else{
            console.log("That name does not exist")
        }
        replace2 = prompt("Are there any names you would still like to replace? (y/n)")
    }while(replace2.toLowerCase() == "y")
console.log(list)
}
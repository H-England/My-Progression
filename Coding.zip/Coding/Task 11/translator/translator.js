//Task 11 - Translator
let retry

let myMap = new Map()
myMap.set("hello", "Bonjour")
myMap.set("bye", "Au revoir")
myMap.set("big", "Grande")
myMap.set("small", "Petite")
myMap.set("morning", "Matin")
myMap.set("evening", "Soir")
myMap.set("dog", "Chien")
myMap.set("cat", "Chat")
myMap.set("cold", "De froid")
myMap.set("hot", "Chaud")



do{
    let translate = prompt("Which word would you like to translate? (Hello, Bye, Big, Small, Morning, Evening, Dog, Cat, Cold or Hot)")
    if(myMap.has(translate) == true){
        
        console.log(myMap.get(translate))
    }else{
        console.log("Please enter one of the words above (Make sure to make it lowercase.)")
    }
    retry = prompt("Would you like to enter another word? (y/n)")
}while(retry.toLowerCase() == "y")
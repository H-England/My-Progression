// I got a review back saying that there was a reference error. I have included a picture as proof that it works for me

let cities = []

let input = prompt("Please Select a City In South Africa (Johannesburg, Cape Town, Soweto, Pietermaritzburg, Pretoria, Durban, Tembisa, East London, Vereeniging, Boksburg)")

i = -1
while(i == -1){

if(input.toLocaleLowerCase() == "johannesburg"){
    i = 0
}else if(input.toLocaleLowerCase() == "cape town"){
    i = 1
}else if(input.toLocaleLowerCase() == "soweto"){
    i = 2
}else if(input.toLocaleLowerCase() == "pietermaritzburg"){
    i = 3
}else if(input.toLocaleLowerCase() == "pretoria"){
    i = 4
}else if(input.toLocaleLowerCase() == "durban"){
    i = 5
}else if(input.toLocaleLowerCase() == "tembisa"){
    i = 6
}else if(input.toLocaleLowerCase() == "east london"){
    i = 7
}else if(input.toLocaleLowerCase() == "vereeiging"){
    i = 8
}else if(input.toLocaleLowerCase() == "boksburg"){
    i = 9
}else{
    input = prompt("Please Select a City In South Africa (Johannesburg, Cape Town, Soweto, Pietermaritzburg, Pretoria, Durban, Tembisa, East London, Vereeniging, Boksburg)")
}
}


const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': 'a5260d9a78msh176f5ea51b8499ep1c0ddajsn19bcdf302864',
		'X-RapidAPI-Host': 'wft-geo-db.p.rapidapi.com'
	}
};

fetch('https://wft-geo-db.p.rapidapi.com/v1/geo/cities?limit=10&countryIds=ZA&minPopulation=400000&sort=-population&types=CITY', options)
	.then(response => response.json())
	.then((response)=>{
        cities = response.data[i]
        cityID = cities.id
        lat = cities.latitude
        long = cities.longitude
        console.log(`The city you have chosen is ${cities.city}.`)
        console.log(`The population of ${cities.city} is ${cities.population} people.`)
    })
	.catch(err => console.error(err));

    setTimeout(function(){
        const options2 = {
        method: 'GET',
        headers: {
            'X-RapidAPI-Key': 'a5260d9a78msh176f5ea51b8499ep1c0ddajsn19bcdf302864',
            'X-RapidAPI-Host': 'wft-geo-db.p.rapidapi.com'
        }
    };
    
    fetch(`https://wft-geo-db.p.rapidapi.com/v1/geo/cities/${cityID}`, options)
        .then(response => response.json())
        .then((response)=>{
            cities2 = response.data
            console.log(`The City ${cities.city} currently sits at ${cities2.elevationMeters}m above sea level.`)
            
        })
        .catch(err => console.error(err));


},2000)

setTimeout(function(){
    const options = {
        method: 'GET',
        headers: {
            'X-RapidAPI-Key': 'a5260d9a78msh176f5ea51b8499ep1c0ddajsn19bcdf302864',
            'X-RapidAPI-Host': 'weatherbit-v1-mashape.p.rapidapi.com'
        }
    };
    
    fetch(`https://weatherbit-v1-mashape.p.rapidapi.com/current?lon=${long}&lat=${lat}&units=metric`, options)
        .then(response => response.json())
    .then((response)=>{
        cities3 = response.data[0]
        temperature = cities3.temp
        console.log(`The Current Temperature of ${cities.city} is ${temperature}\u00B0C`)
    })
	.catch(err => console.error(err));

},4000)


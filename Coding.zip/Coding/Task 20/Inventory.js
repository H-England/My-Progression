//Task 20 - Inventory
class ShoesConstructor{
    constructor(Name, ProductCode, Quantity, Price){
        this.Name = Name
        this.ProductCode = ProductCode
        this.Quantity = Quantity
        this.Price = Price
    }
    getMinPrice(){

    }
}

let nike = new ShoesConstructor("nike", "1", 6, 350)
let jordan = new ShoesConstructor("jordans", "2", 12, 650)
let adidas = new ShoesConstructor("adidas", "3", 93, 120)
let vans = new ShoesConstructor("vans", "4", 7830, 60)
let flipflop = new ShoesConstructor("flipflops", "5", 389209, 10)

let arrShoe = []
let input = prompt("Please enter a shoe name. (nike, jordans, adidas, vans, flipflops)")

arrShoe.push(nike,jordan,adidas,vans,flipflop)

//This is to search for a specific name in the array

function searchIndex(find){
    for(i = 0; i < arrShoe.length; i++){
        if(arrShoe[i].Name == find.toLowerCase()){
        console.log(` ${find} is in the array here is the information on that Shoe`)
        return console.log(arrShoe[i])
        }else{

        }
    }
    return console.log(`${find} is not in the array`)
}

let searched = searchIndex(input)

console.log("--------------------------------------------------------------")
//This is to find the minimum value
function findMin(value){
    value = 100000
    found = 0 
    for(i = 0; i < arrShoe.length; i++){
        if(value > arrShoe[i].Price){
            value = arrShoe[i].Price
            found = i
        }else{

        }
        if(i == 4){
            console.log(`The Lowest price is ${value} which belongs to:`)
            return arrShoe[found]
        }
    }
}

let foundmin = (findMin(100000))
console.log(foundmin)
console.log("--------------------------------------------------------------")

//This is to find the maximum value 
function findMax(value){
    value = -100000
    found = 0 
    for(i = 0; i < arrShoe.length; i++){
        if(value < arrShoe[i].Price){
            value = arrShoe[i].Price
            found = i
        }else{

        }
        if(i == 4){
            console.log(`The Highest price is ${value} which belongs to:`)
            return arrShoe[found]
        }
    }
}

let foundmax = (findMax(100000))
console.log(foundmax)
console.log("--------------------------------------------------------------")
//This is to sort the objects by name in ascending order
arrShoe.sort(function(a, b){
    let nameA = a.Name.toLowerCase()
    let nameB = b.Name.toLowerCase()

    if(nameA < nameB){
        return -1
    }
    if(nameA > nameB){
        return 1
    }

    return 0
});

console.log(arrShoe)
console.log("--------------------------------------------------------------")

//This is to determine whether it is in the array 

let change1 = prompt("Which shoe would you like to change? (nike, jordans, vans, flipflops, adidas)")

let choose = searchIndex(change1)

let change2 = prompt("Which value would you like to change? (Name, ProductCode, quantity, price)")

//This function uses multiple checks to determine which object is to be changed and which part of the object is to be changed.
function searchChange2(name,value){
    if(name.toLowerCase() == "jordans"){
        if(value.toLowerCase() == "name"){
            console.log("You have chosen to change the name")
            changeValue = prompt("What Would you like to change the value to? ")
            jordan.Name = changeValue
        }else if(value.toLowerCase() == "productcode"){
            console.log("You have chosen to change the product code")
            changeValue = prompt("What Would you like to change the value to? ")
            jordan.ProductCode = changeValue
        }else if(value.toLowerCase() == "quantity"){
            console.log("You have chosen to change the quantity")
            changeValue = Number(prompt("What Would you like to change the value to? "))
            jordan.Quantity = changeValue
        }else if(value.toLowerCase() == "price"){
            console.log("You have chosen to change the price")
            changeValue = Number(prompt("What Would you like to change the value to? "))
            jordan.Price = changeValue
        }
    }else if(name.toLowerCase() == "vans"){
        if(value.toLowerCase() == "name"){
            console.log("You have chosen to change the name")
            changeValue = prompt("What Would you like to change the value to? ")
            vans.Name = changeValue
        }else if(value.toLowerCase() == "productcode"){
            console.log("You have chosen to change the product code")
            changeValue = prompt("What Would you like to change the value to? ")
            vans.ProductCode = changeValue
        }else if(value.toLowerCase() == "quantity"){
            console.log("You have chosen to change the quantity")
            changeValue = Number(prompt("What Would you like to change the value to? "))
            vans.Quantity = changeValue
        }else if(value.toLowerCase() == "price"){
            console.log("You have chosen to change the price")
            changeValue = Number(prompt("What Would you like to change the value to? "))
            vans.Price = changeValue
        }
    }else if(name.toLowerCase() == "adidas"){
        if(value.toLowerCase() == "name"){
            console.log("You have chosen to change the name")
            changeValue = prompt("What Would you like to change the value to? ")
            adidas.Name = changeValue
        }else if(value.toLowerCase() == "productcode"){
            console.log("You have chosen to change the product code")
            changeValue = prompt("What Would you like to change the value to? ")
            adidas.ProductCode = changeValue
        }else if(value.toLowerCase() == "quantity"){
            console.log("You have chosen to change the quantity")
            changeValue = Number(prompt("What Would you like to change the value to? "))
            adidas.Quantity = changeValue
        }else if(value.toLowerCase() == "price"){
            console.log("You have chosen to change the price")
            changeValue = Number(prompt("What Would you like to change the value to? "))
            adidas.Price = changeValue
        }
    }else if(name.toLowerCase() == "flipflops"){
        if(value.toLowerCase() == "name"){
            console.log("You have chosen to change the name")
            changeValue = prompt("What Would you like to change the value to? ")
            flipflop.Name = changeValue
        }else if(value.toLowerCase() == "productcode"){
            console.log("You have chosen to change the product code")
            changeValue = prompt("What Would you like to change the value to? ")
            flipflop.ProductCode = changeValue
        }else if(value.toLowerCase() == "quantity"){
            console.log("You have chosen to change the quantity")
            changeValue = Number(prompt("What Would you like to change the value to? "))
            flipflop.Quantity = changeValue
        }else if(value.toLowerCase() == "price"){
            console.log("You have chosen to change the price")
            changeValue = Number(prompt("What Would you like to change the value to? "))
            flipflop.Price = changeValue
        }
    }else if(name.toLowerCase() == "nike"){
        if(value.toLowerCase() == "name"){
            console.log("You have chosen to change the name")
            changeValue = prompt("What Would you like to change the value to? ")
            nike.Name = changeValue
        }else if(value.toLowerCase() == "productcode"){
            console.log("You have chosen to change the product code")
            changeValue = prompt("What Would you like to change the value to? ")
            nike.ProductCode = changeValue
        }else if(value.toLowerCase() == "quantity"){
            console.log("You have chosen to change the quantity")
            changeValue = Number(prompt("What Would you like to change the value to? "))
            nike.Quantity = changeValue
        }else if(value.toLowerCase() == "price"){
            console.log("You have chosen to change the price")
            changeValue = Number(prompt("What Would you like to change the value to? "))
            nike.Price = changeValue
        }
    }
    return console.log(arrShoe)
}


let changed = searchChange2(change1, change2)
// Task 3 (Should you revise)

let score = 80
let hours = 5

let userScore = prompt("What score did you get on your practice test? ")
if (userScore >= score)
    console.log("That is a good score. Well Done")
    else if (userScore <= score)
     console.log("That score is not the best you should do some more revision")
let userHour = prompt("How many hours of revision have you done?")
if (userHour >= hours)
    console.log("That is a lot of revision, take a break")
    else console.log("You should revise for a few more hours")
//Task 4.2 - Water Tarrifs

let litre = prompt(" Please enter the amount of water in litres you have use so that we can determine how much you will be charged. ")

//This is allowed me to visiualise the equation better and in the end helped me do the equation.
let tarrif = (litre / 1000)
let litre1 = (6)
let litre2 = (4.5)
let litre3 = (24.5)


let step1 = (tarrif * 15.73);
let step2 = ((tarrif - 6) * 22.38 + (litre1 * 15.73));
let step3 = ((tarrif - 10.5) * 31.77 + (litre1 * 15.73) + (litre2 * 22.38));
let step4 = ((tarrif - 35)  * 69.76 + (litre1 * 15.73) + (litre2 * 22.38) + (litre3 * 31.77));




if (litre <= 6000 ) {
    console.log("Your water bill is R" + (step1));
    }else if(litre <= 10500 && litre >= 6000){
        console.log("Your water bill is R" + (step2));
    }else if(litre <= 35000 && litre >= 10500){
        console.log("Your water bill is R" + (step3));
    }else if(litre >= 35000){
        console.log("Your water bill is R" + (step4));
    }
     else;
console.log("Thank you")




// The index html on task 2 does not work so I do not know how to link it to a html file so this is the best I can do while it does not work.
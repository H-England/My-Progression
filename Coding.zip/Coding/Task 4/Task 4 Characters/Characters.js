//Task 4 - Character

let letter1 = prompt("Please Enter an uppercase letter, a lowercase letter or number  ")
if(isNaN(letter1)){
    if(letter1.toUpperCase() === letter1){
        console.log((letter1), "Is an uppercase letter.")
    }else if(letter1.toLowerCase() === letter1){
        console.log((letter1), "Is a lowercase letter")
    }else;
    }else{
        console.log((letter1), "Is a Number")
    }
         
    
   
   
   


// The index html on task 2 does not work so I do not know how to link it to a html file so this is the best I can do while it does not work.

//Task 6 - Temperature

// I am creating 3 variables to match with the metric that is inputted so I can easily set up the rest of the code
let celcius = ("C");
let fahrenheit = ("F");
let kelvin = ("K");


let metric1 =  prompt(`Which metric are you converting?  ${celcius} = Celcius ${fahrenheit} = Fahrenheit ${kelvin} = Kelvin`)

//This is the check to check which metric the user inputted
switch(metric1){

    case "C":
        console.log("Thank you")
        break

    case "F":
        console.log("Thank you")
        break

    case "K":
        console.log("Thank you")
        break

    default:
        console.log("Please Choose a given metric Celcius, Fahrenheit, Kelvin ")
        metric1 =  prompt(`Which metric are you converting?  ${celcius} = Celcius ${fahrenheit} = Fahrenheit ${kelvin} = Kelvin`)
        break;
    }


//this is the confirmation for which metric they inputted 
if(metric1 === celcius){
    console.log("You have chosen Celcius");
}else if(metric1 === fahrenheit){
    console.log("You have chosen Fahrenheit");
}else if(metric1 === kelvin){
    console.log("You have chosen Kelvin");
}

//This to aquire the temperature for the conversion
let temp = Number(prompt("What is the Temperature you will be converting? "))

//These are the Equations for all possible answers so that they can be call on
//celcius equations
let f2c = ((temp - 32) * 5/9)
let k2c = (temp - 273.15)



//fahrenheit equations
let c2f = (temp * 9/5 + 32)
let k2f = (temp * 9/5 - 459.67)


//kelvin equations
let c2k = (temp + 273.15)
let f2k = ((temp + 459.67) * 5/9)

let metric2 =  prompt(`Which metric are you converting to?  ${celcius} = Celcius ${fahrenheit} = Fahrenheit ${kelvin} = Kelvin`)

switch(metric2){

    case "C":
        console.log("Thank you")
        break

    case "F":
        console.log("Thank you")
        break

    case "K":
        console.log("Thank you")
        break

    default:
        console.log("Please Choose a given metric Celcius, Fahrenheit, Kelvin ")
        metric2 =  prompt(`Which metric are you converting?  ${celcius} = Celcius ${fahrenheit} = Fahrenheit ${kelvin} = Kelvin`)
        break;
    }

if(metric2 === celcius){
    console.log("You have chosen to convert to Celcius");
}else if(metric2 === fahrenheit){
    console.log("You have chosen to convert to Fahrenheit");
}else if(metric2 === kelvin){
    console.log("You have chosen to convert to Kelvin");
}

//call on the equations for celcius
if(metric1 == fahrenheit && metric2 === celcius){
    console.log(`The conversion of ${temp}\u00B0F to Celcius is ${f2c}\u00B0C`)
}else if(metric1 === kelvin && metric2 === celcius){
    console.log(`The conversion of ${temp}K to Celcius is ${k2c}\u00B0C`)
}else if(metric1 === celcius && metric2 === celcius){
    console.log(`There is no conversion need as you chose the same metric for both ${temp}\u00B0C`)
}else;

//calling on the equations for fahrenheit
if(metric1 === celcius && metric2 === fahrenheit){
    console.log(`The conversion of ${temp}\u00B0C to Fahrenheit is ${c2f}\u00B0F`)
}else if(metric1 === kelvin && metric2 === fahrenheit){
    console.log(`The conversion of ${temp}K to Fahrenheit is ${k2f}\u00B0F`)
}else if(metric1 === fahrenheit && metric2 === fahrenheit){
    console.log(`There is no conversion need as you chose the same metric for both ${temp}\u00B0F`)
}else;

//calling on the equations for kelvin
if(metric1 === celcius && metric2 === kelvin){
    console.log(`The conversion of ${temp}\u00B0C to Kelvin is ${c2k}K`)
}else if(metric1 === fahrenheit && metric2 === kelvin){
    console.log(`The conversion of ${temp}\u00B0F to Kelvin is ${f2k}K`)
}else if(metric1 === kelvin && metric2 === kelvin){
    console.log(`There is no conversion need as you chose the same metric for both ${temp}K`)
}

// The html file from task 2 is still not working so this is only the java script part

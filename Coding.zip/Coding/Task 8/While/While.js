//Task 8.1 While

let number = Number(prompt("Please Enter a number. "));
console.log(number);
let value = 1;
let num2 = 0;
num2 = num2 + number;

while(number !== -1){
    number = Number(prompt("Please Enter a number. "))
    num2 = num2 + number;
    value = value + 1;
    console.log(num2)
}
//this is to account for the -1 entered to end the loop
num2 = num2 + 1
value = value - 1


let avg = num2 / value
console.log(`The total of all the numbers you inputted are ${num2}`)
console.log(`The Average of the total number are ${avg}`)

//Task 8 Palidromes

let word1 = prompt("Please Enter a word. ")
let word2 = ""
let value = word1.length;
let answer= "y"

while(value--){
    word1 = word1.toLowerCase()
    word2 = word2 + word1[value]
    } 
    //These Console logs are to show what you inputted and the input reversed for the user to visualise that it is a palindrome.
    console.log(word1)
    console.log(word2)   
    if (word1 === word2){
        console.log(`${word1} is a Palidrome`)
    }else{
        console.log(`${word1} is not a Palidrome`)
}


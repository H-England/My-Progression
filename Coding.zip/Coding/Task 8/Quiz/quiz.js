//Task 8.3 Quiz
let sky = ""
let answer = ""
do{
    sky = prompt("What colour is the sky? \na. Purple\nb. Pink\nc. Blue\nd. Yellow") 
    if(sky.toLowerCase() == "c"){
        answer = "n"
    }else{
        answer = prompt("Would you like to try again (y/n)")
    }
}while(answer.toLowerCase() == "y" );


if(sky.toLowerCase() == "c"){
    console.log("Well Done it was C")
}else;

   
    

    
function multiply(a){
    //Closure Function
    return function multiply2(b){
        //For Loop to time the value but the amount of times in putted 1 by 1
        for(i = 0; i < a; i++){
            console.log(`${i} x ${b} = ${i * b}`)
        }
        return console.log(`${a} x ${b} = ${a * b}`)
    }
}
const call = multiply(10)
call(10)
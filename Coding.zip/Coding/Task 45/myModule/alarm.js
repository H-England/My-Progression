let counter = 0

function soundAlarm(){
    counter++
    console.log("Stop Snoozing. Get out of Bed!")
    if(counter == 6){
        console.log("You are going to be late!")
        clearInterval(noise)
    }
}

let noise = setInterval(soundAlarm, 1000)
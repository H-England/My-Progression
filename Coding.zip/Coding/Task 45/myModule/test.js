const lodash = require("lodash")

let people = ["Joel","Tommy","Ellie","Marlene","Tess"]
console.log(lodash.first(people))
let myName = ("Harry")

console.log(`Hello ${myName}`)
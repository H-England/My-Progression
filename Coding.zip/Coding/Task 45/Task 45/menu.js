let item1 = ("Carbonara")
let item2 = ("Pink Panther Wafers")
let item3 = ("Oxtail Stew")

console.log(`1.${item1}
2.${item2}
3.${item3}`)
import logo from './robotree2.png';
import './App.css';
import Welcome from './Components/landingPad';
import Produce from './Components/products';
import Navbar from './navigation';
import Home from './pages/Home';
import Shopping from './pages/Shopping';
import Legal from './pages/Legal';
import User from './pages/User';
import Interest from './pages/Interest';



const products = [
  {prodName: "T-Shirt", price: "£12", stock:21093},
  {prodName: "Scientist Gloves", price: "£10", stock:1043274},
  {prodName: "Scientist coat", price: "£25", stock:0}
]

function App() {
  let component
  switch(window.location.pathname){
    case "/":
      component = <Home></Home>
      break
    case "/shopping":
      component = <Shopping></Shopping>
      break
    case "/user":
      component = <User></User>
      break
    case "/legal":
      component = <Legal></Legal>
      break
    case "/interest":
      component = <Interest></Interest>
    break
  }
  return (
    <div>
      <Navbar/>
      {component}
    </div>
  );
}

export default App;

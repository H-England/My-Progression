import logo from "../robotree2.png"
import { Button } from "react-bootstrap"
import React, {useState} from "react"

//This is no longer used as I moved it on to the user page.
// const Btn = () => {

//     const [toggle, setToggle] = useState(false)

//     const toggler = () => {
//         toggle ? setToggle(false): setToggle(true)
//     }
//     return(
//         <div>
//             <Button onClick={toggler} id="btn"className="btn btn-primary">Sign In</Button>
//             {toggle ? <h1>Welcome Back Reviewer to</h1> : <h1>Welcome New User to</h1>}
//         </div>
//     )
// }
//This is the base of the home page with all the details a home page would have
function Welcome() {
    

    return(
        <div className="topDiv">
            <img src={logo} className="App-logo" alt="Biomax Prosthetics Logo"/>
            <div className="home">
                <header>
                    <h1 className="App-header">Biomax Prosthetics Clothing</h1>
                    <h2 className="bordered">Company Back Ground</h2>
                    <p className="bordered">Welcome to "Biomax Prosthetics," a leading Biomedical Prosthetics Company dedicated to improving the lives of individuals with physical disabilities. Our company was founded in 2005 by a group of biomedical engineers who recognized the need for advanced prosthetics technology that could provide better mobility and functionality for individuals with amputations and other physical impairments.
                        At Biomax Prosthetics, we are committed to developing cutting-edge prosthetics that are designed to meet the unique needs and preferences of our clients. We offer a wide range of prosthetic devices, including upper and lower limb prosthetics, as well as specialized prosthetics for specific activities such as running, swimming, and playing sports.
                        Our team of experienced engineers, designers, and technicians work closely with our clients to ensure that each prosthetic device is customized to their specific needs and preferences. We use advanced 3D printing and scanning technology to create precise, comfortable, and high-performance prosthetics that enable our clients to live their lives to the fullest.
                        At Biomax Prosthetics, we are dedicated to providing the highest level of care and support to our clients. We offer ongoing maintenance, repair, and adjustment services to ensure that our clients' prosthetic devices remain in optimal condition and continue to meet their evolving needs.
                        Our mission at Biomax Prosthetics is to empower individuals with physical disabilities to live their lives with confidence and independence. We are committed to advancing the field of biomedical prosthetics and making a positive impact on the lives of our clients and their families. This is the Branch of the Company that sells merchandise to fund our efforts to enhance the future of humans.
                    </p>
                </header>
            </div>
        </div>
    )
}

export default Welcome;
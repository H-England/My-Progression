
//This is a function that takes props to display the names of each stock Item
function Produce (props){
    const name = props.prodName
    const price = props.price

    let message = ""
    message = `Stock Remaining: ${props.stock}`

    return(
        <div>
            <h5>{name}</h5>
            <h6>{price}</h6>
            <p>{message}</p>
        </div>
    )
}









export default Produce
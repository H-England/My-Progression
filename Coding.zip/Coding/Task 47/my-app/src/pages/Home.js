import Welcome from "../Components/landingPad"
import "../App.css"

export default function Home(){
    return <Welcome></Welcome>
}
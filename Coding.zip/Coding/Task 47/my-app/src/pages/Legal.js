import "../App.css"


export default function Legal(){
    return (
        <body>
            <h1>Legal Stuff</h1>
            <p className="legal">
                Welcome to the website of the biomedical engineering company, Biomax Prosthetics. The information provided on this website is for general informational purposes only and does not constitute medical advice or establish a doctor-patient relationship.
                Prosthetic Solutions is not a medical provider and does not provide medical services or treatment. Our company specializes in the design and development of prosthetic devices for amputees and individuals with limb loss.
                The information provided on this website may not reflect current medical developments and is not a substitute for medical advice from a qualified healthcare professional. Prosthetic Solutions does not assume any responsibility for the accuracy or completeness of the information on this website.
                The use of this website does not create a doctor-patient relationship and should not be used as a substitute for seeking medical advice from a qualified healthcare professional. Any communication through this website, including email or contact form submissions, does not create a doctor-patient relationship. Please do not send confidential or sensitive medical information through this website.
                Prosthetic Solutions takes the privacy and security of your personal information seriously. Please review our Privacy Policy for more information on how we collect, use, and protect your personal information.
            </p>
        </body>
    )
}
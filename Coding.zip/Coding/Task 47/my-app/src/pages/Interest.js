import { Button } from "react-bootstrap"
import "../App.css"

//I used a function to create an interest calculator, using prompts which are the nicest to look at but still work well.
function Calc(){
    let total = 0 
    let months = 0
    let int = 0
    total = prompt("What is the total of your items?")
    months = prompt("How many months would you like to pay this in?")
    if(months == 0){
        int = total
    }else{
        int = Number(parseFloat((total / months) * 1.2).toFixed(2))
        alert(`£ ${int} per month.`)
    }
}
// I used Bootstrap buttons for nicer appearances
export default function Interest(){
    return (
        <body>
            <h1>Interest</h1>
            <p className="legal">
                For our Mechandise we offer a two payment options. You can pay in full, or you can pay monthly.
                However there is an Interest Rate of 20%.
            </p>
            <h4>To Calculate the Cost of Your Items Please Press the Button Below</h4>
            <Button onClick={Calc}>Interest Calculator</Button>
        </body>
    )
}
import { Button } from "react-bootstrap"
import 'bootstrap/dist/css/bootstrap.min.css';
import React, {useState} from "react";
import "../App.css"

function logout(){
    alert("You Have logged Out")
}

//I used a function to create states for the buttons allowing a simple sign in and log out.
const Btn = () => {

    const [toggle, setToggle] = useState(false)

    const toggler = () => {
        toggle ? setToggle(false): setToggle(true)
    }
    return(
        <div>
            {toggle ? <h1>Welcome Back Reviewer</h1> : <h1>Welcome new user</h1>}
            <h4>If you are not a new User please Sign In</h4>
            <Button onClick={toggler} id="btn"className="btn btn-primary btn-lg">Sign In</Button>
        </div>
    )
    }
export default function User(){
    return(
        <body>
            <div className="user">
                <h1>Please Log In</h1>
                <Btn></Btn>
                <div className="btntopright">
                    <Button onClick={logout} className="btn btn-primary btn-lg">Log Out</Button>
                </div>
            </div>
        </body>
    ) 
}
import Produce from "../Components/products"


//This is where the props come from
const products = [
    {prodName: "T-Shirt", price: "£12", stock:21093},
    {prodName: "Scientist Gloves", price: "£10", stock:1043274},
    {prodName: "Scientist coat", price: "£25", stock:0}
  ]

//This is how I display the items.
export default function Shopping(){
    const renderArr = products.map((product,index) => {
     return (
       <li className="bordered" key={index+product.prodName}>
         <Produce prodName = {product.prodName} price = {product.price} stock = {product.stock}/>
       </li>
     )
   })
    return (
        <div>
            <h1>Shopping</h1>
            <ul className="list">
                {renderArr}
            </ul>
        </div>
    )


}



// I used a Switch Statment as although they aren't the best for react in this example it works well and is simple
export default function Navbar(){
    return <nav className="nav">
        <a href="/" className="site-title">Biomax Prosthetics</a>
        <ul>
            <li className="active">
                <a href="/shopping">Shopping</a>
            </li>
            <li className="active">
                <a href="/user">User Profile</a>
            </li>
            <li className="active">
                <a href="/legal">Legal</a>
            </li>
            <li className="active">
                <a href="/interest">Interest</a>
            </li>
        </ul>
    </nav>
}
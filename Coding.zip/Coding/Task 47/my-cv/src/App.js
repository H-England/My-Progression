import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1 className= "bordered">Curriculum Vitae</h1>
        <h2>Harry England</h2>
        <h3 className= "bordered">Personal Details</h3>
        <p>Date of Birth: 06/06/2000</p>
        <p>Nationality: British</p>
        <h5 className= "bordered">Location</h5>
        <p>Address: 43a Richford Street</p>
        <p>City: London</p>
        <p>County: Hammersmith</p>
        <p>Postcode: W6 7HJ</p>
        <h5 className= "bordered">Contact Information</h5>
        <p>Mobile: 07833045513</p>
        <p>Email:</p>
        <h3 className= "bordered">Achievements</h3>
        <ul className='list'>
          <li>
            Passed All 10 GCSE's with C or Higher at Portland Place School in 2016.<br/>
          </li>
          <br/>
          <li>
            Biology at A Grade just shy of an A*
          </li>
          <br/>
          <li>
            English Language, English Literature, Media Studies, Additional Science with a B grade.
          </li>
          <br/>
          <li>
            Computer Science, Design and Tech, Geography and Maths at C Grade.
          </li>
          <br/>
          <li>
            Able to build a fully functioning computer from scratch.
          </li>
          <br/>
          <li>
            Multiple Medals for Sports.
          </li>
          <br/>
          <li>
            Earned Young Mathematician Trophy at the age of 8.
          </li>
          <br/>
          <li>
            Very Confident Independent Flier.
          </li>
          <br/>
          <li>
            Confident Bartender and Cocktail Bartender.
          </li>
          <br/>
          <li>
            Confident with the majority of JavaScript, HTML, css.
          </li>
          <br/>
          <li>
            Currently Learning React and have a Basic knowledge of Pascal.
          </li>
          <br/>
          <li>
            Work well in groups and with people.
          </li>
          
        </ul>
        <h3 className= "bordered">Previous Work Experience</h3>
        <ul className='list'>
          <li>
            Worked on a Farm for a while during the Summer of 2015
          </li>
          <li>
            Worked at many Bars over the past 4 Years and have atleast 3 1/2 Years of Experience making Cocktails and serving drinks.
          </li>
        </ul>
        <h3 className= "bordered" >Summary</h3>
          <p className='padded'>
            In recent months starting in December, I joined a coding BootCamp with Hyperion Dev learning Web Development, 
            in which I have learned how to code using JavaScript, HTML, CSS confidently, and the basics of react. With a month still to go at the time of writing this.
            Although this isn't a long time of coding I have had previous experience during my GCSEs and A-levels and plan to continue to develop my skills with an employer or by myself.
            I am very confident with Object orientation in JavaScript, CSS styling, and the inner working of HTML. Out of JavaScript, HTML, and CSS, I would say I am the most experienced and the most confident in using Javascript.
          </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;

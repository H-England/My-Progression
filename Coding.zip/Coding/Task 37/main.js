let grocery = ["Apples", "Cat Food", "Beef", "Chicken"]

let list = document.getElementById("itemList")

//This function was my way of updating the list so that the array was outputted on top of the original list. So Each time you input an item it removes the list and adds it back with the new item.
function emptyList(){
    for(let i = 0; i < grocery.length; i++){
    const removeitem = document.getElementById(`Items${i}`)
    const removecross = document.getElementById(`cross`)
    removeitem.remove()
    removecross.remove()
    }
}
//This is the function that creates the list from the array and what you input
function addList(){
    for(let i = 0; i < grocery.length; i++){
        let listitems = document.createElement("li")
        let cross = document.createElement("span")
        cross.className = "close"
        cross.id = `cross`
        cross.onclick = deleteItem
        cross.innerHTML = `\u00D7`
        listitems.id = `Items${i}`
        listitems.innerHTML = grocery[i]
        listitems.setAttribute("onclick",'checked(this)')
        list.appendChild(listitems)
        listitems.appendChild(cross)
    }
}


//This function is called whenever the add item button is press or the enter key is press and will update the list.
function updateList(){
    let input = document.getElementById("input")

    if(input.value == ""){
        alert("Please Input an item.")
    }else{
        emptyList()
        grocery.push(input.value)
        console.log(grocery)
        addList()
        input.value = ""   
    }

}
//This is the delete function which is called when clicked on the x
function deleteItem(e){
    e.target.parentNode.style.display = "none"
    let remove =  e.target.parentNode.innerHTML
    grocery.splice(remove, 1)

}

let enter = document.getElementById("input")

// This event allows you to press enter instead of pressing the button every time
enter.addEventListener("keypress", (e) => {
    if(e.key === "Enter"){
        event.preventDefault()
        document.getElementById("addBtn").click()
    }
})

addList()

//This function allows you to check items off the list by changing the style
function checked(e){
    if(e.className !== "checked"){
        e.className = "checked"
    }else{
        e.className = "styles2"
    }
}

imageStore = []
textStore = []

markImage = document.querySelectorAll(".up")

markImage.addEventListener("click", () => {
    console.log(markImage.target.parentElement)
})
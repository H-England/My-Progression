//this is the footer element 
export default function Footer(){
    return(
        <div className="divfoot">
            <footer className="footer2">
                <ul>
                    <li>
                        United Kingdom
                    </li>
                </ul>
            </footer>
            <footer className="footer">
                <ul className="botleft">
                    <li className="footli">
                        Advertising
                    </li>
                    <li className="footli">
                        Business
                    </li>
                    <li className="footli">
                        How Search Works
                    </li>
                </ul>
                <ul>
                    <li className="footli" >
                        <a href="https://www.google.com">Google.com</a>
                    </li>
                </ul>
                <ul className="botright">
                    <li className="footli">
                        Privacy
                    </li>
                    <li className="footli">
                        Terms
                    </li>
                    <li className="footli">
                        Settings
                    </li>
                </ul>
            </footer>
        </div>
    )
}
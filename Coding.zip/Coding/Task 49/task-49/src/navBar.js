import google from "./Google button.png"
import profile from "./profile image.png"
//this is the navbar that google has at the top of the page.
export default function NavBar(){
    return(
        <nav className="nav">
            <ul className="topleft">
                <li>
                    About
                </li>
                <li>
                    Store
                </li>
            </ul>
            <ul className="topright">
                <li>
                    Gmail
                </li>
                <li>
                    Images
                </li>
                <li>
                    <img className="button" src={google}></img>
                </li>
                <li>
                    <img className="profile" src={profile}></img>
                </li>
            </ul>
        </nav>
    )
}
import logo from './logo.svg';
import './App.css';
import NavBar from './navBar';
import camera from "./camera.png"
import glass from "./magnifying.png"
import Footer from './footer';

//This is the base of the page
function App() {
  return (
    <body>
      <NavBar></NavBar>
      <h1>Google</h1>
      <div className='search'>
        <div className='input'>
          <img src={glass}></img>
          <input className='box'></input>
          <img src={camera}></img>
        </div>
      </div>
      <div className='divBtn'>
        <button className='googlebtn'>Google Search</button>
        <button className='googlebtn'>I'm Feeling Lucky</button>
      </div>
      <Footer></Footer>
    </body>
  );
}

export default App;
//I didn't use props are there is nowhere I can really use props for this page.
// Task 3.2 Fortune Teller

let motherName = prompt("What is your mothers name? ")
let street = prompt("What is the name of the street you grew up on? ")
let colour = prompt("What is your favourite colour? ")
let age = Number(prompt("How old are you? "))
let num1 = Number(prompt("Choose a number between 1 and 10"))
let year = Math.round(age / num1)

//Below Im doing the equation here for the amount of children to make the long multi-lined string neater
let num2 =(Math.round(age / num1 ) - age / num1)
let child = Math.round(num2 * 10)

console.log(child)

//I used a while loop here to make sure the user can't bypass the 1-10 part of this question
while (num1 >= 10 || num1 <= 0 ){
    console.log("Please choose another number but this time between 1 and 10")
    alert("Please choose another number but this time between 1 and 10")
    num1 = Number(prompt("Choose a number between 1 and 10"))}

console.log ("Thank you I will now read your fortune")
console.log(`In ${num1} years you will meet your best friend named  ${motherName} ${street}.
You will get married in ${year} and have  ${child} children. 
In ${age - num1}, years you are going to dye your hair ${colour}.`)
//The Task asks to do something with Html however the PDF from task 2 about HTML does not work so I just did it in normal Js
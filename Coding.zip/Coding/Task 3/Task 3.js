// Task 3 : Variables and Datatypes

// Integer
let myFirstNumber = 5
console.log("myFirstNumber with the value of " + myFirstNumber + " is a datatype of " + typeof myFirstNumber)

let mySecondNumber = 12
console.log("mySecondNumber with the value of " + mySecondNumber + " is a datatype of " + typeof mySecondNumber)

//String
let myFirstString = "Harry"
console.log("myFirstString with the value of " + myFirstString + " is a datatype of " + typeof myFirstString)

let mySecondString = "England"
console.log("mySecondString with the value of " + mySecondString + " is a datatype of " + typeof mySecondString)

//Floats

let height = 180.5
console.log("height with the value of " + height + " is a datatype of " + typeof height + " however it is actually a float due to a decimal point")

//Boolean

let myBoolean = true
console.log("myBoolean with the value of " + myBoolean + " is a datatype of " + typeof myBoolean)

//The multiline string
console.log(" ")
console.log(" ")

console.log("5 x 12 = " + (myFirstNumber * mySecondNumber))

console.log(myFirstString + mySecondString)

console.log(`The Boolean is: ${myBoolean}.
My first number is: ${myFirstNumber}.
The second number is: ${mySecondNumber}.
5 + 12 = ${myFirstNumber + mySecondNumber}.
The first string is: ${myFirstString}. 
The Second String is: ${mySecondString}.
These two together make: ${myFirstString + mySecondString}.`)
//Task 23 - Capstone - OOP
//Class for base Salary Employees
class SalariedEmploy{
    constructor(name, type, sales, salaries, pay){
        this.name = name
        this.type = type
        this.sales = sales
        this.salaries = salaries
        this.pay = pay 
    }
    
}
//Class for Hourly Paid Employees
class HourlyEmploy extends SalariedEmploy{
    constructor(name, type, sales, salaries, hours, pay){
        super(name, type, sales, salaries, pay)
        this.hours = hours
    }
    
}
//Class for Hybrid Employees
class HybridEmploy extends SalariedEmploy{
    constructor(name, type, sales, salaries, hours, pay){
        super(name, type, sales, salaries, pay)
        this.hours = hours
    }
}

//This Function is to calculate the salary.
function calcPay(person){
    if(person.type == "salaried"){
        if(person.sales >= 100){
            person.pay = person.salaries * 1.1
            console.log(`${person.name}'s who is a ${person.type} paid employee. Their pay was calculated by add 10% onto their salary (salary x 1.1) which gave them an income of $${person.pay}`) 
        }else if(person.sales < 100){
            person.pay = person.salaries
            console.log(`${person.name}'s who is a ${person.type} paid employee. Their pay was not need to be calculated as they did not hit the sales target which gave them an income of $${person.pay}`) 
        }
    }else if(person.type == "hourly"){
        if(person.sales >= 100){
            person.pay = (person.hours * person.salaries) * 1.50
            console.log(`${person.name}'s who is a ${person.type} paid employee's pay was calculated by ((hours x salary) x 1.5) due to hitting the sales target which gave them an income of $${person.pay}`)
        }else if(person.sales < 100){
            person.pay = person.hours * person.salaries
            console.log(`${person.name}'s who is a ${person.type} paid employee's pay was calculated by (hours x Salary) which gave them an income of $${person.pay}`)
        }
    }else if(person.type == "hybrid"){
        if(person.sales >= 100){
            person.pay = ((person.salaries * 1.2) + (person.hours * 20.37))
            console.log(`${person.name}'s who is a ${person.type} employee pay was calculated by ((Salary x 1.2) + (Hours x 20.37)) which gave them an income of $${person.pay}`)
        }else if(person.sales < 100){
            person.pay = person.salaries + (person.hours * 20.37)
            console.log(`${person.name}'s who is a ${person.type} employee pay was calculated by (hours x 20.37 + Salary) which gave them an income of $${person.pay}`)
        }
    }

}

//The Employees
let bob = new SalariedEmploy("Bob", "salaried", 100, 2500, 0)
let jeff = new SalariedEmploy("Jeff", "salaried", 99, 2700, 0)
let john = new HourlyEmploy("John", "hourly", 250, 16.5, 160, 0)
let scott = new HourlyEmploy("Scott", "hourly", 93, 14.25, 72, 0)
let boob = new HybridEmploy("Brain", "hybrid", 99, 2100, 30, 0)
let gerald = new HybridEmploy("Gerald", "hybrid", 913, 1900, 67, 0)

//Calling the function for Each Employee
let bobPay = calcPay(bob)
let jeffPay = calcPay(jeff)
let johnPay = calcPay(john)
let scottPay =  calcPay(scott)
let brianPay = calcPay(boob)
let gerPay = calcPay(gerald)

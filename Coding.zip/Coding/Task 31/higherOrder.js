let wordArr = ["People", "Ring", "Microphone","Domino","Bottle","Cleaner","Death","Life","Crispr","Biology"]

//The function used in the call back.
function wordLength(word){
    if(word.length == 6){
        return true
    }
}

//The Higher order function.
function myFilterFunction(wordArr, callback){
    const newArr = []
    //This loop is used to go through each word.
    for(i = 0; i < wordArr.length; i++){
        //This if statement is used to check whether the word that goes through the call back is 6 letters or not.
        if(callback(wordArr[i]) == true){
            //finally if it is 6 letters it pushes it into a new array.
            newArr.push(wordArr[i])
        }
    }
    return console.log(newArr)
}

myFilterFunction(wordArr, wordLength)
import logo from './earth.png';
import './App.css';
import { Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { InputGroup } from 'react-bootstrap';
import { Form } from 'react-bootstrap';
import { useEffect, useRef, useState } from 'react';

let input = ""
let country
let probability




function App() {

  const [name, setName] = useState("")
  const [location, setLocation] = useState("")
  const [prob, setProb] = useState("")

  const inputRef = useRef()

  useEffect(() => {
    inputRef.current.focus()

  })

  const inputtedName = () => {
    input = document.getElementById("input").value
    setName(input)
    Nationality()
  }

  function Nationality(){
    fetch(`https://api.nationalize.io?name=${input}`)
    .then(result => result.json())
    .then((result) => {
      setLocation(result.country[0].country_id)
      setProb((result.country[0].probability) * 100)
      console.log(prob)
    })
  }

  
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className = "App-logo"></img>
        <h1>Name Nationality Guesser</h1>
        <div className='indiv'>
          <InputGroup className='mb-3'>
            <Form.Control
              placeholder='Please Enter a Name'
              aria-label='Please Enter a Name'
              aria-describedby='basic-addon2'
              id='input'
              ref={inputRef}
              value = {name}
              onChange={e => setName(e.target.value)}
            />
            <Button onClick={inputtedName} id='button-addon2'>
              Submit
            </Button>

          </InputGroup>
        </div>
        <div id='result'>
          <h3>{name}</h3>
          <h5>Country: {location}</h5>
          <h5>Probability: {prob}%</h5>
        </div>
      </header>
    </div>
  );
}

export default App;

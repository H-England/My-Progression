import { createSlice } from "@reduxjs/toolkit";

export const balanceSlice = createSlice({
    name: "balance",
    initialState: {
        balance: 0
    },
    reducers: {
        interest: (state) => {
            state.balance *= 1.005
        },
        charge: (state) => {
            state.balance *= 0.85
        },
        deposit: (state, action) => {
            state.balance += action.payload
        },
        withdraw: (state, action) => {
            state.balance -= action.payload
        }
    }
})

export const {deposit, withdraw, interest, charge} = balanceSlice.actions

export default balanceSlice.reducer
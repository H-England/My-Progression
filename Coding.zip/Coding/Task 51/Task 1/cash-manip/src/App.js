import React, { useState } from 'react';
import './App.css';
import { Button, Container, Form, InputGroup } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useDispatch, useSelector } from 'react-redux';
import { charge, deposit, interest, withdraw } from './app/slice';


function App() {
  const {balance} = useSelector((state) => state.money)
  const dispatch = useDispatch()
  const [depo, setDepo] = useState(0)
  const [withd, setWithd] = useState(0)

  return (
    <div className="App">
      <header className="header">
        <h1>England Accounting</h1>
      </header>
      <body>
        <div className='depo'>
          <div className='sep'>
            <h2>Deposit</h2>
              <Container className='depo2'>
                  <InputGroup className='depo1'>
                    <Form.Control
                      size='true'
                      placeholder='Deposit Amount'
                      aria-label='Please Enter a Name'
                      aria-describedby='basic-addon2'
                      className='depo2'
                      id='depo'
                      value={depo}
                      onChange={e => setDepo(e.target.value)}
                    />
                  <Button id='button-addon2' onClick={() => dispatch(deposit(Number(depo)))}>
                    Deposit
                  </Button>
              </InputGroup>
            </Container>
          </div>
          <div className='sep'>
            <h2>Withdraw</h2>
            <Container className='depo2'>
                  <InputGroup className='depo1'>
                    <Form.Control
                      size='true'
                      placeholder='Withdrawal Amount'
                      aria-label='Please Enter a Name'
                      aria-describedby='basic-addon2'
                      id='with'
                      value={withd}
                      onChange={e => setWithd(e.target.value)}
                    />
                  <Button id='button-addon2'  onClick={() => dispatch(withdraw(Number(withd)))}>
                    Withdraw
                  </Button>
              </InputGroup>
            </Container>
          </div>
        </div>
        <div className='depo'>
        <div className='sep'>
            <h2>Interest</h2>
            <h6>To add Interest Press the Button Below</h6>
              <Container className='depo2'>
                  <Button id='button-addon2' onClick={() => dispatch(interest())}>
                    Add Interest
                  </Button>
            </Container>
          </div>
          <div className='sep'>
            <h2>Charges</h2>
            <h6>To add Charges Press the Button Below</h6>
            <Container className='depo2'>
                  <Button id='button-addon2' onClick={() => dispatch(charge())}>
                    Add Charge
                  </Button>
            </Container>
          </div>
        </div>
        <div className='sep2'>
          <div className='sep3'>
            <h2>Current Balance</h2>
            <h3>£{parseFloat(balance).toFixed(2)}</h3>
          </div>
        </div>
      </body>
    </div>
  );
}

export default App;

import React, { useRef } from "react";
import { Button, Container, Form, InputGroup } from 'react-bootstrap';

const Tasks = (props) => {
    const {task, updateTodo, removeTodo, completeTodo} = props

    const inputRef = useRef(true)

    const changeFocus = () => {
        inputRef.current.disabled = false
        inputRef.current.focus()
    }

    const update = (id, value, e) => {
        if(e.which === 13){
            updateTodo({id, task:value })
            inputRef.current.disabled = true;
        }
    }
    
    return(
        <div className="sep4">
            <li className="singlist" key={task.id}>
                <textarea
                    className="textbox" 
                    ref={inputRef} 
                    disabled={inputRef}
                    defaultValue={task.task}
                    onKeyPress={(e) => update(task.id, inputRef.current.value, e)}
                />
                <Button variant='info' className='btn' onClick={() => changeFocus()}>Edit</Button>
                <Button variant='danger' className='btn' onClick={() => removeTodo(task.id)}>Delete</Button>
                <Button variant='success' className='btn' onClick={() => completeTodo(task.id)}>Completed</Button>{" "}
            </li>
        </div>
    )
}

export default Tasks
import React, { useState } from "react";
import { connect } from "react-redux";
import { addTodos, removeTodos, updateTodos, completeTodos } from "./slice";
import { Button, Container, Form, InputGroup } from 'react-bootstrap';
import Tasks from "./Tasks";

const stateToProps = (state) => {
    return {
        todos: state,
    }
}

const dispatchtoProps = (dispatch) => {
    return {
        addTodo: (obj) => dispatch(addTodos(obj)),
        removeTodo: (id) => dispatch(removeTodos(id)),
        updateTodo: (obj) => dispatch(updateTodos(obj)),
        completeTodo: (obj) => dispatch(completeTodos(obj)) 
    }
}

const DisplayTasks = (props) => {
    const [sort, setSort] = useState("active")
    return(
        <div>
            <div className="sepBtn">
                <Button onClick = {() => setSort("active")}>Active</Button>
                <Button onClick={() => setSort("completed")}>Completed</Button>
            </div>
            <ul>
                {
                    props.todos.length > 0 && sort === "active" ?

                    props.todos.map(task => {
                        return(
                            task.completed === false &&
                            <Tasks
                                key={task.id}
                                task={task}
                                removeTodo={props.removeTodo}
                                updateTodo={props.updateTodo}
                                completeTodo={props.completeTodo}
                            />
                        )
                    }) 
                
                : null}
                {
                    props.todos.length > 0 && sort === "completed" ?

                    props.todos.map(task => {
                        return(
                            task.completed === true &&
                            <Tasks
                                key={task.id}
                                task={task}
                                removeTodo={props.removeTodo}
                                updateTodo={props.updateTodo}
                                completeTodo={props.completeTodo}
                            />
                        )
                    }) 
                
                : null}
                
            </ul>
        </div>
    )
}

export default connect(stateToProps,dispatchtoProps)(DisplayTasks)
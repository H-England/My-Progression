import { useRef, useState } from "react";
import { Button, Container, Form, InputGroup } from 'react-bootstrap';
import { connect } from "react-redux";
import DisplayTasks from "./DisplayTasks";
import { addTodos, completeTodos, removeTodos, updateTodos } from "./slice";

const stateToProps = (state) => {
    return {
        todos: state,
    }
}

const dispatchtoProps = (dispatch) => {
    return {
        addTodo: (obj) => dispatch(addTodos(obj)),
        removeTodo: (id) => dispatch(removeTodos(id)),
        updateTodo: (obj) => dispatch(updateTodos(obj)),
        completeTodo: (obj) => dispatch(completeTodos(obj)) 
    }
}



const Todos = (props) => {
    const [todo, setTodo] = useState("")

    const handleChange = (e) => {
        setTodo(e.target.value)
    }
    console.log("Props from store", props)
    return (
        <div>
            <h2>To-Do List</h2>
                <Container className='depo2'>
                  <InputGroup className='depo1'>
                    <Form.Control
                      size='true'
                      placeholder='Enter a Task'
                      aria-label='Please Enter a Name'
                      aria-describedby='basic-addon2'
                      className='depo2'
                      type='text'
                      onChange={(e) => handleChange(e)}
                      id='depo'
                    />
                  <Button id='button-addon2' onClick={() => props.addTodo({
                    id: Math.floor(Math.random()*1000),
                    task:todo,
                    completed:false
                  })}>Add Task</Button>
              </InputGroup>
            </Container>
            <DisplayTasks/>
            <ul className='alllist'>
                {props.todos.map((task) => {
                    return (
                        <div></div>
                    )
                })}
            </ul>
        </div>
    )
}

export default connect(stateToProps,dispatchtoProps)(Todos)
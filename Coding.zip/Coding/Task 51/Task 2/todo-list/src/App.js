import React, { useState } from 'react';
import './App.css';
import { Button, Container, Form, InputGroup } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useDispatch, useSelector } from 'react-redux';
import Todos from "./app/actions"
import DisplayTasks from './app/DisplayTasks';
// import { charge, deposit, interest, withdraw } from './app/slice';


function App() {

  return (
    <div className="App">
      <header className="header">
        <h1>Harry England's To-Do List</h1>
      </header>
      <body>
        <div className='depo'>
        <div className='sep'>
          <Todos></Todos>
            </div>
        </div>
      </body>
    </div>
  );
}

export default App;

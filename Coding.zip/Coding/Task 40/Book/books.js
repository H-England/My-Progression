let books = []
let counter = 0

//Function to accurately store elements
function startCount() {
   counter = books.length
 
}



let list = document.getElementById("list")

//creates book elements from books array
const addBook2 = () => {
    let newRow = document.createElement("tr")
    let titles = document.createElement("th")
    let authors = document.createElement("th")
    let genres = document.createElement("th")
    let reviews = document.createElement("th")
    let editBtn = document.createElement("button")
    let delBtn = document.createElement("button")
    newRow.id = `${books[counter].bookId}`
    titles.id = `${books[counter].bookId}`
    authors.id = `${books[counter].bookId}`
    genres.id = `${books[counter].bookId}`
    reviews.id = `${books[counter].bookId}`
    editBtn.id = `${books[counter].bookId}`
    delBtn.id = `${books[counter].bookId}`
    editBtn.setAttribute("onclick", "editBook(this)")
    delBtn.setAttribute("onclick", "deleteBook(this)")
    titles.innerHTML = `${books[counter].title}`
    authors.innerHTML = `${books[counter].author}`
    genres.innerHTML = `${books[counter].genre}`
    reviews.innerHTML = `${books[counter].review}`
    editBtn.innerHTML = "Edit"
    delBtn.innerHTML = "Delete"
    counter++
    list.appendChild(newRow)
    newRow.appendChild(titles)
    newRow.appendChild(authors)
    newRow.appendChild(genres)
    newRow.appendChild(reviews)
    newRow.appendChild(editBtn)
    newRow.appendChild(delBtn)
}


//Creates books from inputs
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById("button").addEventListener("click", addBook = (e) => {
        e.preventDefault() // To stop the form from refreshing the page.
        let book = {
        title: document.getElementById("title").value,
        author: document.getElementById("author").value,
        genre: document.getElementById("genre").value,
        review: document.getElementById("rating").value,
        bookId: Date.now()
    }
    books.push(book)
    sessionStorage.setItem("Books", JSON.stringify(books))
    document.querySelector("form").reset()   //This is to reset the form for a new entry
    addBook2()
    })
})

//Function to restore array from storage
window.addEventListener("load", () => {
    if(sessionStorage.getItem("Books") == null){
    }else{
        books = (JSON.parse(sessionStorage.getItem("Books")))
        
        startCount()
        storage() 
    }
})


//Restores the table of books
const storage = () => {
    for(i = 0; i < books.length; i++){
            let newRow = document.createElement("tr")
            let titles = document.createElement("th")
            let authors = document.createElement("th")
            let genres = document.createElement("th")
            let reviews = document.createElement("th")
            let editBtn = document.createElement("button")
            let delBtn = document.createElement("button")
            newRow.id =  `${books[i].bookId}`
            titles.id =  `${books[i].bookId}`
            authors.id =  `${books[i].bookId}`
            genres.id =  `${books[i].bookId}`
            reviews.id =  `${books[i].bookId}`
            editBtn.id =  `${books[i].bookId}`
            delBtn.id = `${books[i].bookId}`
            editBtn.setAttribute("onclick", "editBook(this)")
            delBtn.setAttribute("onclick", "deleteBook(this)")
            titles.innerHTML = books[i].title
            authors.innerHTML = books[i].author
            genres.innerHTML = books[i].genre
            reviews.innerHTML = books[i].review
            editBtn.innerHTML = "Edit"
            delBtn.innerHTML = "Delete"
            list.appendChild(newRow)
            newRow.appendChild(titles)
            newRow.appendChild(authors)
            newRow.appendChild(genres)
            newRow.appendChild(reviews)
            newRow.appendChild(editBtn)
            newRow.appendChild(delBtn)
        }
}
//the Delete function to remove books
function deleteBook(e){
    let element =  document.getElementById(e.id)
    
    element.remove()
    for(p = 0; p < books.length; p++ ){
        if(e.id == books[p].bookId){
            books.splice([p], 1)
        }
        sessionStorage.removeItem("Books")
        sessionStorage.setItem("Books", JSON.stringify(books))
        startCount()
    }
}

//the function to edit books 
const editBook = (f) => {
    for(o = 0; o < books.length; o++){  
        if(f.id == books[o].bookId){
            inputBox1 = document.getElementById("title")
            inputBox2 = document.getElementById("author")
            inputBox3 = document.getElementById("genre")
            inputBox4 = document.getElementById("rating")
            inputBox1.value = books[o].title
            inputBox2.value = books[o].author
            inputBox3.value = books[o].genre
            inputBox4.value = books[o].review
            let element2 = document.getElementById(f.id)
            element2.remove()
            books.splice([o], 1)
            sessionStorage.removeItem("Books")
            sessionStorage.setItem("Books", JSON.stringify(books))
            startCount()
        }
    }
    
}

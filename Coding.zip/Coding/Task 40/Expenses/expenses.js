incomeArr = []
expenseArr = []
let incCounter1 = 0
let expCounter1 = 0
let incCounter2 = 0
let expCounter2 = 0
let storagecount = 0



incomebtn = document.getElementById("btninc")
incomelist = document.getElementById("incList")
// These Functions create the Objects and then create the elements from the objects
incomebtn.addEventListener("click", function(){
    nameinc = prompt("Please Enter the Name of the Income:")
    if(nameinc == null){
        nameinc = prompt("Please Enter the Name of the Income:")
    }
    amountinc = Number(prompt("Please Enter the Amount of Income Generated:"))
    if(amountinc == 0){
        amountinc = Number(prompt("Please Enter the Amount of Income Generated:"))
    }
    recurrinc = prompt("Is this a Recurring Income? (Yes or No)")

    let inc = {
        name: nameinc,
        inc: amountinc,
        recinc: recurrinc
    }
    incomeArr.push(inc)
    sessionStorage.setItem("Income", JSON.stringify(incomeArr))
    addInc()
})

const addInc = () =>{
    let incRow = document.createElement("tr")
    let incName = document.createElement("th")
    let incAmount = document.createElement("th")
    let incRecur = document.createElement("th")
    incName.innerHTML = `${incomeArr[incCounter1].name}`
    incAmount.innerHTML = `\&#163 ${incomeArr[incCounter1].inc}`
    incRecur.innerHTML = `${incomeArr[incCounter1].recinc}`
    incAmount.className = "green"
    incomelist.appendChild(incRow)
    incRow.appendChild(incName)
    incRow.appendChild(incAmount)
    incRow.appendChild(incRecur)
    incCounter1++

    reset()
    incTotal()
}

expensebtn = document.getElementById("btnexp")
expenselist = document.getElementById("expList")

expensebtn.addEventListener("click", function(){
    nameexp = prompt("Please Enter the Name of the Expense:")
    if(nameexp == null){
        nameexp = prompt("Please Enter the Name of the Expense:")
    }
    amountexp = Number(prompt("Please Enter the Amount of Expenditure:"))
    if(amountexp == 0){
        amountexp = Number(prompt("Please Enter the Amount of Expenditure:"))
    }
    recurrexp = prompt("Is this a Recurring Expense? (Yes or No)")

    let exp = {
        name: nameexp,
        exp: amountexp,
        recexp: recurrexp
    }
    expenseArr.push(exp)
    sessionStorage.setItem("Expense", JSON.stringify(expenseArr))
    addExp()
})

const addExp = () =>{
    let expRow = document.createElement("tr")
    let expName = document.createElement("th")
    let expAmount = document.createElement("th")
    let expRecur = document.createElement("th")
    expName.innerHTML = `${expenseArr[expCounter1].name}`
    expAmount.innerHTML = `\&#163 ${expenseArr[expCounter1].exp}`
    expRecur.innerHTML = `${expenseArr[expCounter1].recexp}`
    expAmount.className = "red"
    expenselist.appendChild(expRow)
    expRow.appendChild(expName)
    expRow.appendChild(expAmount)
    expRow.appendChild(expRecur)
    expCounter1++

    reset()
    expTotal()
}

function reset(){
    nameinc = ""
    amountinc = 0
    recurrinc = ""
    nameexp = ""
    amountexp = ""
    recurrexp = ""
}

let value1 = 0
let value2 = 0
inctotal = document.getElementById("total1")
exptotal = document.getElementById("total2")
finalTotal1 = document.getElementById("total3")
finalTotal2 = document.getElementById("total4")

//These Functions Create the totals from the inputted Objects
const incTotal = () => {
    let incCounter2 = -1

    for(i = 0; i < incomeArr.length; i++){
        incCounter2++
    }
    value1 = Number(parseFloat(value1 + incomeArr[incCounter2].inc).toFixed(2))
    inctotal.innerHTML =  `\&#163 ${value1}`
    finalTotal1.innerHTML = `\&#163 ${value1}`
    
}

const expTotal = () => {
    let expCounter2 = -1
    for(j = 0; j < expenseArr.length; j++){
        expCounter2++
    }
    value2 = Number(parseFloat(value2 + expenseArr[expCounter2].exp).toFixed(2))
    exptotal.innerHTML = `\&#163 ${value2}`
    finalTotal2.innerHTML = `\&#163 ${value2}`
}

//This Section of code creates the disposable and savings
saved = document.getElementById("savings")
dispos = document.getElementById("disposable")

conf = document.getElementById("btn")
conf.addEventListener("click", function(){
    savings = Number(prompt("Much Would you like to save this month?"))
    saved.innerHTML = `\&#163 ${savings}`
    dispos.innerHTML = `\&#163 ${Number(parseFloat((value1 - value2) - savings).toFixed(2))}`
})

//Event Lister to add objects back into arrays
window.addEventListener("load", () => {
    if(sessionStorage.getItem("Income") == null){

    }else{
        incomeArr = (JSON.parse(sessionStorage.getItem("Income")))
        incStorage()
    }

    if(sessionStorage.getItem("Expense") == null){
        
    }else{
        expenseArr = (JSON.parse(sessionStorage.getItem("Expense")))
        expStorage()
    }
})

//Functions Below to Create totals from storage
const incSTotal = () => {
    for(i = 0; i < incomeArr.length; i++){
        value1 = Number(parseFloat(value1 + incomeArr[i].inc).toFixed(2))
    }
    inctotal.innerHTML =  `\&#163 ${value1}`
    finalTotal1.innerHTML = `\&#163 ${value1}`
}

const expSTotal = () => {
    for(j = 0; j < expenseArr.length; j++){
        value2 = Number(parseFloat(value2 + expenseArr[j].exp).toFixed(2))

        
    }
    exptotal.innerHTML = `\&#163 ${value2}`
    finalTotal2.innerHTML = `\&#163 ${value2}`
}

//Functions Below to Pull From Storage

const incStorage = () => {
    for(i = 0; i < incomeArr.length; i++){
        let incRow = document.createElement("tr")
        let incName = document.createElement("th")
        let incAmount = document.createElement("th")
        let incRecur = document.createElement("th")
        incName.innerHTML = `${incomeArr[i].name}`
        incAmount.innerHTML = `\&#163 ${incomeArr[i].inc}`
        incRecur.innerHTML = `${incomeArr[i].recinc}`
        incAmount.className = "green"
        incomelist.appendChild(incRow)
        incRow.appendChild(incName)
        incRow.appendChild(incAmount)
        incRow.appendChild(incRecur)
        incCounter1++
    
        console.log(incomeArr[0].inc)
        
    }
    reset()
    incSTotal()
}

const expStorage = () => {
    for(j = 0; j < expenseArr.length; j++){
        let expRow = document.createElement("tr")
        let expName = document.createElement("th")
        let expAmount = document.createElement("th")
        let expRecur = document.createElement("th")
        expName.innerHTML = `${expenseArr[j].name}`
        expAmount.innerHTML = `\&#163 ${expenseArr[j].exp}`
        expRecur.innerHTML = `${expenseArr[j].recexp}`
        expAmount.className = "red"
        expenselist.appendChild(expRow)
        expRow.appendChild(expName)
        expRow.appendChild(expAmount)
        expRow.appendChild(expRecur)
        expCounter1++

    
    }
    reset()
    expSTotal()
}


// Define arrays
const rowWin = [
    ["O", "O", "O"],
    ["", "", ""],
    ["", "", ""]
]

const colWin = [
    ["", "X", ""],
    ["", "X", ""],
    ["", "X", ""]
]

const diagonalWin = [
    ["", "", "O"],
    ["", "O", ""],
    ["O", "", ""]
]

const diagonalWinInverse = [
    ["X", "", ""],
    ["", "X", ""],
    ["", "", "X"]
]

// evaluatePlay function.
// Within this function, write the code to evaluate weather a winning play has been made or not
// Your program must be able to evaluate all the grids defined above.
// The function should inform the user of which sign has  won and which sign has lost
// You may add additional parameters to assist you
function evaluatePlay(grid){
let rowsWinX
let rowsWinO
let colsWinX
let colsWinO
let diagWinX
let diagWinO

//Rows For X

if(grid[0][0] === "X" && grid[0][1] === "X" && grid[0][2] === "X"){
    console.log("Top Row Victory For X!\nO Lost!")
}else if(grid[1][0] === "X" && grid[1][1] === "X" && grid[1][2] === "X"){
    console.log("Mid Row Victory For X!\nO Lost!")
}else if(grid[2][0] === "X" && grid[2][1] === "X" && grid[2][2] === "X"){
    console.log("Bottom Row Victory For X!\nO Lost!")
}else{
    rowsWinX = -1
}
//Rows For O

if(grid[0][0] === "O" && grid[0][1] === "O" && grid[0][2] === "O"){
    console.log("Top Row Victory For O!\nX Lost!")
}else if(grid[1][0] === "O" && grid[1][1] === "O" && grid[1][2] === "O"){
    console.log("Mid Row Victory For O!\nX Lost!")
}else if(grid[2][0] === "O" && grid[2][1] === "O" && grid[2][2] === "O"){
    console.log("Bottom Row Victory For O!\nX Lost!")
}else{
    rowsWinO = -1
}

//Cols For X

if(grid[0][0] === "X" && grid[1][0] === "X" && grid[2][0] === "X"){
    console.log("Far left Column Victory for X!\nO Lost!")
}else if(grid[0][1] === "X" && grid[1][1] === "X" && grid[2][1] === "X"){
    console.log("Middle Column Victory for X!\nO Lost!")
}else if(grid[0][2] === "X" && grid[1][2] === "X" && grid[2][2] === "X"){
    console.log("Far left Column Victory for X!\nO Lost!")
}else{
    colsWinX = -1
}

// Cols For O

if(grid[0][0] === "O" && grid[1][0] === "O" && grid[2][0] === "O"){
    console.log("Far left Column Victory for O!\nX Lost!")
}else if(grid[0][1] === "O" && grid[1][1] === "O" && grid[2][1] === "O"){
    console.log("Middle Column Victory for O!\nX Lost!")
}else if(grid[0][2] === "O" && grid[1][2] === "O" && grid[2][2] === "O"){
    console.log("Far left Column Victory for O!\nX Lost!")
}else{
    colsWinO = -1
}
//Diag For X

if(grid[0][0] === "X" && grid[1][1] === "X" && grid[2][2] === "X"){
    console.log("Diagonal Left to Right Victory for X!\nO Lost!")
}else if(grid[0][2] === "X" && grid[1][1] === "X" && grid[2][0] === "X"){
    console.log("Diagolnal Right to left Victory for X!\nO Lost!")
}else{
    diagWinX = -1
} 
//Diag For O

if(grid[0][0] === "O" && grid[1][1] === "O" && grid[2][2] === "O"){
    console.log("Diagonal Left to Right Victory for O!\nX Lost!")
}else if(grid[0][2] === "O" && grid[1][1] === "O" && grid[2][0] === "O"){
    console.log("Diagolnal Right to left Victory for O!\nX Lost!")
}else{
    diagWinO = -1
}
if(rowsWinX === -1 && colsWinX === -1 && diagWinX === -1){
    console.log("No Wins for X were found.")
} 
if(rowsWinO === -1 && colsWinO === -1 && diagWinO === -1){
    console.log("No Wins for O were found.")
}
}
console.log("----------------------------------------------------------")
result1 = evaluatePlay(rowWin)
console.log("----------------------------------------------------------")
result2 = evaluatePlay(colWin)
console.log("----------------------------------------------------------")
result3 = evaluatePlay(diagonalWin)
console.log("----------------------------------------------------------")
result4 = evaluatePlay(diagonalWinInverse)
console.log("----------------------------------------------------------")

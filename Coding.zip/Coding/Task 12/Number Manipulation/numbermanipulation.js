//Task 12 - Number Manipulation

let arr = []
let number
let total = 0
let index1 = 0
let index2 = 0
let counter = 0
let avg = 0
let median = 0



do{
    number = Number(prompt("Please Enter 10 Numbers"))
    arr.push(number)
    total = total + number
    counter = counter + 1
}while(arr.length <= 9)

console.log("The numbers you inputted are " + arr)

//The Total
console.log("The total of the numbers you inputted are " + total)

//The Indexes
index1 = arr.indexOf(Math.max(...arr))
console.log("The index of the maximum number is " + index1)

index2 = arr.indexOf(Math.min(...arr))
console.log("The index of the maximum number is " + index2)

//Average Calculations
avg = (total / counter)
console.log("The average of the numbers inputted is " + avg.toFixed(2))

//Median Calculations
arr.sort(function(a, b){return a - b})
console.log(arr)
median = (arr[5] + arr[4]) / 2
console.log(median.toFixed(2))

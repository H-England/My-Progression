
let num1
let num2
let operation = ""
let total

const addition = () => {
     total = num1 + num2
    
}

const subtract = () => {
     total = num1 - num2 
}

const multiply = () => {
     total = num1 * num2
}

const divide = () => {
     total = num1 / num2
}

num1 = Number(prompt("Please Enter the first number"))
num2 = Number(prompt("Please enter the second number"))
operation = prompt("Please enter the operation you would like to use on these numbers (+, -, * or /")

if(operation === "+"){
   addition(num1, num2) 
   console.log(`${num1} + ${num2} = ${total}`)
}else if(operation === "-"){
    subtract(num1, num2)
    console.log(`${num1} - ${num2} = ${total}`)
}else if(operation === "*"){
    multiply(num1, num2)
    console.log(`${num1} x ${num2} = ${total}`)
}else if(operation === "/"){
    divide(num1, num2)
    console.log(`${num1} / ${num2} = ${total}`)
}else{
    console.log("Please enter one of the 4 operations.")
}


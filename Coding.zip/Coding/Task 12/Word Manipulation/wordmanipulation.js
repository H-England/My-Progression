//Task 12 - WordManipulation

let string1 = prompt("Please Enter A Word ")
let string2 = string1.split("")
let string3 = string1
let count
let upper = ""

//This is for the ASCII values
for(let i = 0; i < string1.length; i++){
   console.log(string1.charCodeAt(i))
}

//This is for replacing every other character with !
for(let x = 1; x < string2.length; x += 2){
   string2[x] = "!"
}

console.log(string2.join(""))





//this is for making every 6th letter a capital
for(let y = 0; y < string3.length; y++){ 
   if(y % 6 == 0){
 upper = upper + string3[y].toUpperCase();
   } else {
    upper = upper + string3[y].toLowerCase();
   }
}

console.log(upper)

//reversing string
function reverse(string1){
   return string1.split("").reverse().join("");
}
reverse(string1)



separationString = (myString) => {
    // Place your code here
    let arr = []
    let newStr
    for(let i = 0;  i < myString.length; i++){
        newStr = myString
        newStr = newStr.replaceAll(" ", "\n")
    }
    
    return newStr
}


// DO NOT EDIT BELOW THIS LINE
let testStrings = [
    "Hello World",
    "Hello",
    "HELLO",
    "Software Engineering is Fun",
    "I like Javascript",
    "Line1 Line2 Line3 Line4 Line5 Line6 Line7 Line8 Line9"
];

console.log("------------------------------------------------")

testStrings.forEach((sentence) => {
    let sep = separationString(sentence);
    console.log(sep);
    console.log("------------------------------------------------")

});


alternativeString = (myString) => {
    // Place your code here
    let arr = []

    for(let i = 0; i < myString.length; i ++){
        upper = ""
            if( i % 2 == 0){
                
                upper = upper + myString[i].toUpperCase()
            } else if(i % 2 == 1){
                
                upper = upper + myString[i].toLowerCase()
            }

            arr.push(upper)
            arr.join(",", "")
        }
        let result =  arr.join("")
        return result 



}

// for(let i = 0; i < myString.length; i ++){
//     let upper = "" 
     
//          if( i % 2 == 0){
            
//              upper = upper + myString[i].toUpperCase()
//          } else if(i % 2 == 1){
             
//              upper = upper + myString[i].toLowerCase()
//          }
         
         
         
//      }
//      return upper 
     
 

// }



// DO NOT EDIT BELOW THIS LINE
let myString = [
    "Hello World",
    "Hello",
    "HELLO",
    "Software Engineering is Fun",
    "I like Javascript",
    "clown case"
]

let correctStrings = [
    "HeLlO WoRlD",
    "HeLlO",
    "HeLlO",
    "SoFtWaRe eNgInEeRiNg iS FuN",
    "I LiKe jAvAsCrIpT",
    "ClOwN CaSe"
]

for (let strIdx = 0; strIdx < myString.length; strIdx++) {
    let test = myString[strIdx];
    let correct = correctStrings[strIdx];

    let got = alternativeString(test);
    

    if (got == correct) {
        console.log(`${strIdx + 1}: Testing ${test}: Correct!`);
    } else {
        console.log(`${strIdx + 1}: Testing ${test}: Wrong, got ${got}, expected ${correct}`);
    }
}

import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import reportWebVitals from './reportWebVitals';
import logo from "./maxresdefault.jpg"

const user = {
  fName: "Harry",
  sName: "England",
  dob: 6,
  mob: "June",
  yob: 2000,
  address: "1 Downing Street",
  country: "England",
  email: "harryengland666@gmail.com",
  telephone: "07843021117",
  company: "Biomedical Enterprises",
  profilepic: logo,
  shoppingcart: ["apples", "carrots", "lollipops", "ice"]


}

const element = (
  <div>
    
    <h1>Welcome Back <i>{user.fName} {user.sName}</i></h1><img src={user.profilepic} alt="Profile Picture"/>
    <div id='style1'>
      <h3>Logged In with: {user.email}</h3>
      <h3>Date of Birth: {user.dob}/{user.mob}/{user.yob}</h3>
      <h3>Address: {user.address}</h3>
      <h3>Country Of Address: {user.country}</h3>
      <h3>Saved Mobile Phone Number: {user.telephone}</h3>
      <h3>Company: {user.company}</h3>
    </div>
    <ul>Shopping Cart:
      <li>{user.shoppingcart[0]}</li>
      <li>{user.shoppingcart[1]}</li>
      <li>{user.shoppingcart[2]}</li>
      <li>{user.shoppingcart[3]}</li>
    </ul>

  </div>
)

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {element}
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

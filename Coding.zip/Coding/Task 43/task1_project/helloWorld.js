let word = input("Input Something")
console.log(word)
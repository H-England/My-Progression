let dataArray = ["java","html","javascript","css"]

function searchIndex(word, index){
    if(index === 4){
    return console.log(-1)}

    if(dataArray[index] == input.toLowerCase()){
        return console.log(1)
    }else{
        return searchIndex(word, index + 1)
    }
}

let input = prompt("Enter a word to see if its in the array")

let result = searchIndex(input, 0)
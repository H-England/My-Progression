let input = prompt("Please enter a word")
let size = input.length - 1


function reverseSent(word, position){
    if(position === 0){
        return word[0] 
   }
    return word[position] + reverseSent(word, position - 1)
}

let newWord = reverseSent(input,size)
console.log(newWord)
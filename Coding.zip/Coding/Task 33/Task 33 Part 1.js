fetch("https://www.affirmations.dev/")
.then(result => result.json())
.then((result) => {
    items = result
    console.log(items)
})
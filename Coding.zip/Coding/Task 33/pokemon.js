fetch("https://pokeapi.co/api/v2/pokemon/pikachu")
.then(result => result.json())
.then((result) => {
    //Using the result. to get specific values and putting them into variables.
    pokemon = result.name
    console.log(pokemon)
    weight = result.weight
    console.log(weight)
    //Abilities Come out as Objects to get them to appear correctly I used a html addon to get them to appear correctly however you can use stringify too.
    ability = result.abilities[0]
    ability2 = result.abilities[1]
     console.log(ability)
     console.log(ability2)   
})
//Task 2.1 - Greetings

let myName = prompt("Please enter your name: ")
console.log(`Your name is: ${myName}`)
let myAge = prompt("Please enter your age: ")
console.log(`Your age is: ${myAge}`)
alert(`You are ${myName} and you're' ${myAge} years old. Nice to meet you!`)
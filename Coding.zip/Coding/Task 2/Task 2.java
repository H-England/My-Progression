// Task 2

let myName = prompt( message: "Please enter your name: ")
console.log(`Your name is: ${myName}`)
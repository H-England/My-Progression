// Task 2.2 Shopping list

alert("Tell me what three items you would like to add to the shopping list.")
let item1 = prompt("The First item is? ")
let item2 = prompt("The Second item is? ")
let item3 = prompt("The Third item is? ")
 
alert(`The three items that were added to your shopping list are:
${item1} 
${item2} 
${item3}`)
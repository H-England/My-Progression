//turned printValueOf into a function from a variable
function printValuesOf(jsObject, keys){
  for (let i = 0; i <= keys.length; i++) {
    let key = keys[i];
    //changed k to key to make the key variable work
    console.log(jsObject[key]);
  }
}

let simpsonsCatchphrases = {
  lisa: 'BAAAAAART!',
  bart: 'Eat My Shorts!',
  marge: 'Mmm~mmmmm',
  //added an escape character
  homer: 'd\'oh!',
  maggie: '(Pacifier Suck)',
};

//added brackets to make the calling of the function work with the specified keys of the object
printValuesOf(simpsonsCatchphrases, ['lisa', 'bart', 'homer']);

// Expected console output:

// BAAAAAART!
// Eat My Shorts!
// d'oh!

// Returns undefined

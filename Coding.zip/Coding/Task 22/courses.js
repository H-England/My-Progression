//Task 22 - Courses

class Courses{
    constructor(courseName, contactWebsite){
        this.courseName = courseName
        this.contactWebsite = contactWebsite
    }
    get WebInfo(){
        return `The Contact Website is ${this.contactWebsite}`
    }


}
class Subjects extends Courses{
    constructor(courseName,contactWebsite ,subject , price){
        super(courseName, contactWebsite)
        this.subject = subject
        this.price = price
    }

    get SubjectInfo(){
        return `The Subject ${this.subject} belongs to the course ${this.courseName} and it will cost ${this.price}`

    }
}

let biology = new Subjects("Science", "www.scientology.com", "Biology", 4000)
let english = new Subjects("English", "www.learnenglish.com", "English Language", 3500)
let computer = new Subjects("Computer Science", "www.webdevelopment.com", "Web Development", 7000)

console.log(biology.WebInfo)
console.log(computer.SubjectInfo)
const express = require("express")
const app = require("express")()

const foo = require("./person.json")

app.set("view engine", "ejs")




app.use(express.static("public"))

app.get("/",(req, res) => {
    res.send(`Welcome ${foo.name}`)
})

app.listen(3000)
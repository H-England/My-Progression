const btnlist = document.querySelectorAll(".up");
imgCount = 0
textCount = 0
imageStore = []
textStore = []

const savedImg = document.getElementById("imglist")
const savedText = document.getElementById("textlist")

btnlist.forEach(btnEl => {
    btnEl.addEventListener("click", () => {
        if(btnEl.classList.contains("active") == true){
            btnEl.classList.remove("active")
        }else{
            btnEl.classList.add("active")
        }
    })
})

const marklist = document.querySelectorAll(".mark");

marklist.forEach(markEl => {
    markEl.addEventListener("click", (e) => {
        if(markEl.classList.contains("active") == true){
            markEl.classList.remove("active")
        }else{
            markEl.classList.add("active")
        }
        imgCount++
        
        alert(`You have saved ${imgCount} Images`)
        f = e.target.parentElement
        i = f.parentElement
        imgId = i.firstElementChild.getAttribute("src")
        imageStore.push(imgId)
        console.log(imageStore)
        sessionStorage.setItem("Image", JSON.stringify(imageStore))
    })
})

const marklist2 = document.querySelectorAll(".mark2");

marklist2.forEach(markEl => {
    markEl.addEventListener("click", (e) => {
        if(markEl.classList.contains("active") == true){
            markEl.classList.remove("active")
        }else{
            markEl.classList.add("active")
        }
        textCount++
        
        alert(`You have saved ${textCount} Articles`)
        f = e.target.parentElement
        i = f.parentElement
        textId = i.firstElementChild.innerHTML
        console.log(textId)
        textStore.push(textId)
        console.log(textStore)
        sessionStorage.setItem("Text", JSON.stringify(textStore))
    })
})

window.addEventListener("load", () => {
    if(sessionStorage.getItem("Image") == null){

    }else{
        imageStore = (JSON.parse(sessionStorage.getItem("Image")))
        console.log(imageStore)
        imgCount = imageStore.length
        addImg()
    }
    if(sessionStorage.getItem("Text") == null){

    }else{
        textStore = (JSON.parse(sessionStorage.getItem("Text")))
        console.log(textStore)
        textCount = textStore.length
        addText()
    }

})
const addImg = () => {
    for(i = 0; i < imageStore.length; i++){
        let imList = document.createElement("li")
        let img = document.createElement("img")
        img.setAttribute("src", imageStore[i])
        img.className = "driverimage"
        savedImg.appendChild(imList)
        imList.appendChild(img)
    }
    
}
const addText = () => {
    for(i = 0; i < textStore.length; i++){
        let tList = document.createElement("li")
        let text = document.createElement("p")
        tList.className = "tlist"
        text.innerHTML = textStore[i]
        savedText.appendChild(tList)
        tList.appendChild(text)
    }
    
}
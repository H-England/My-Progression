// imageStore = []
// textStore = []
// imgCount = 0
// imgId = ""

// const savedImg = document.getElementById("imglist")
// const savedText = document.getElementById("textlist")

// const markImg = document.querySelectorAll(".mark")



// markImg.forEach(markEl => {
//     markEl.addEventListener("click", (e) => {
//         imgCount++
        
//         alert(`You have saved ${imgCount} Images`)
//         f = e.target.parentElement
//         i = f.parentElement
//         imgId = i.firstElementChild
//         sessionStorage.setItem("Image", JSON.stringify(imgId))
//     } )
// })

// const markText = document.getElementById

// // markImg.forEach(markEl => {
// //     markEl.addEventListener("click", (e) => {
// //         imgCount++
// //         alert(`You have saved ${imgCount} Images`)
// //         f = e.target.parentElement
// //         i = f.parentElement
        
// //         imgId = i.firstElementChild
// //         imageStore.push(imgId)
// //         sessionStorage.setItem("Image", JSON.stringify(imageStore))

// //     } )
// // })



// // window.addEventListener("load", () => {
// //     if(sessionStorage.getItem("savedImg") == null){

// //     }else{
// //         imageStore = (JSON.parse(sessionStorage.getItem("saveImg")))
// //         addImg()
// //     }


// // })


// // const addImg = () => {
// //     for(i = 0; i < imageStore.length; i++){
// //         let imList = document.createElement("li")
// //         imList.innerHTML = `${imgId}`
// //         savedImg.appendChild(imList)
// //     }
    
// // }
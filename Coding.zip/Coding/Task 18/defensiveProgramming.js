//Task 18 - Defensive Programming

let input = prompt("What do you want to calculate ? (Distance(m)/Time(s)/Speed(m))")

let speed
let distance
let time

if(input.toLowerCase() === "distance"){

    speed = Number(prompt("Please enter the speed?"))
    time = Number(prompt("Please input the time taken"))
    distance = (speed * time)

    console.log(`The distance travelled was ${distance}`)

}else if(input.toLowerCase() === "time"){

    distance = Number(prompt("Please enter the distance travelled"))
    speed = Number(prompt("Please enter the speed?"))
    time = (distance / speed)

    console.log(`The Time it took to travel ${distance} metres at a speed of ${speed} metres per second was ${time} seconds`)

}else if(input.toLowerCase() === "speed"){

    time = Number(prompt("Please input the time taken"))
    distance = Number(prompt("Please enter the distance travelled"))
    speed = (distance / time)
    
    console.log(`It took ${time} seconds to travel a distance of ${distance} metres giving it a speed of ${speed} metres per second`)
}
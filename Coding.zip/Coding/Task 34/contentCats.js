//Simple async function with and await before the fetch.
const contentCat = async () => {
    //I used a different link as it return an error each time but this link works
    let gif  = await fetch("https://api.thecatapi.com/v1/images/search")
    console.log(gif.url)
    return gif

}

contentCat()